#own create file

from unicodedata import name
from django.urls import path
from . import views



urlpatterns = [
    path('', views.Advising, name='advising'),
    path('delete/', views.deleteTaken, name='delete'),
    path('advising_by_faculty/', views.AdvisingByFaculty, name='advising_by_faculty'),
    path('course_taken/', views.CourseTake, name='course_taken'),
    path('delete_by_faculty/', views.deleteByFaculty, name='delete_by_faculty'),
    path('f_schedule/', views.FacultySchedule, name='f_schedule'),
    path('f_grade/', views.FacultyGradeReport, name='f_grade'),

]
