from django.contrib import admin
from .models import Student, Faculty,User

admin.site.register(User)
admin.site.register(Student)
admin.site.register(Faculty)


