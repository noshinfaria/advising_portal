from django.http import JsonResponse
from django.shortcuts import render, redirect, HttpResponse
from .models import User, Student
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.generic import CreateView, ListView
from .forms import StudentSignUpForm,FacultySignUpForm, DeptForm,CreateSemesterForm, AssignCourseForm
from .forms import StudentSignUpForm,FacultySignUpForm, DeptForm,CreateSemesterForm, AssignCourseForm
from advising.models import Create_Semester, DropSemesterRequest,TakeCourse,DropStatus
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Q



def Homepage(request):
    return render(request, 'home/homepage.html')


class StudentSignUpView(CreateView):
    model = User
    form_class = StudentSignUpForm
    template_name = 'home/student_signup.html'

    def get_context_data(self, **kwargs):
        kwargs['user_type'] = 'student'
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        #login(self.request, user)
        return redirect('home')


class FacultySignUpView(CreateView):
    model = User
    form_class = FacultySignUpForm
    template_name = 'home/faculty_signup.html'

    def get_context_data(self, **kwargs):
        kwargs['user_type'] = 'faculty'
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        #login(self.request, user)
        return redirect('home')


@login_required
def Profile(request):
    return render(request, 'home/profile.html')


def DeptView(request):
    form = DeptForm
    if request.method == 'POST':
        deptform = DeptForm(request.POST)
        print(deptform)
        if deptform.is_valid():
            deptform.save()
            messages.success(request, 'submit successfully')
            return redirect('department')

    return render(request, 'home/department.html', {'form': form})


def CreateSemesterView(request):
    form = CreateSemesterForm
    if request.method == 'POST':
        semesterform = CreateSemesterForm(request.POST)

        if semesterform.is_valid():
            semesterform.save()
            messages.success(request, 'submit successfully')
            return redirect('create_semester')

    return render(request, 'home/create_semester.html', {'form': form})


def AssignCourseView(request):
    form = AssignCourseForm
    if request.method == 'POST':
        assignform = AssignCourseForm(request.POST)

        if assignform.is_valid():
            assignform.save()
            messages.success(request, 'submit successfully')
            return redirect('advised_course')

    return render(request, 'home/advised_course.html', {'form': form})
    
@csrf_exempt
def Schedule(request):
    semester = Create_Semester.objects.values()

    obj = {
        'semesters': semester,
        'courses': 'Null'
    }
    if request.method=='POST':
        s = request.POST['semester']

        course = (TakeCourse.objects.filter(student_info=request.user.id, current_semester=s))

        obj = {
        'semesters': semester,
        'courses': course
        }
    return render(request, 'home/classSchedule.html', obj)


@csrf_exempt
def semester_drop(request):
    semester = Create_Semester.objects.values()

    obj = {
        'semesters': semester,
        'courses': 'Null'
    }
    if request.method=='POST':
        s = request.POST['semester']
        msg=request.POST['msg']
        saved=DropSemesterRequest(student_info=request.user,message=msg,semester=s)
        saved.save()
        
        
    return render(request,'home/semester_drop.html',obj)

@csrf_exempt
def drop_request(request):
    req=DropSemesterRequest.objects.all()
    user = User.objects.filter(is_student=True)
    
    semester = Create_Semester.objects.values()

    context = {
        'user': user,
        'semester': semester,
        'student': 'Null',
        'add': 'Null',
        "req":req

    }
    if request.method=='POST':
        stu = request.POST['user']
        s = request.POST['semester']
        courses=TakeCourse.objects.filter(student_info=stu,current_semester=s)
        # drop=DropStatus(student_info=)

        courses.delete()
        
        
        
        drop=DropStatus(student_info=stu,semester=s,status=True)
        drop.save()
        print(stu,s)
        # print(courses)
    
    return render(request,'home/drop_request.html',context)